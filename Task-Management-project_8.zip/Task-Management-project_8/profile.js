// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
    'use strict'
        window.addEventListener('load', function () {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation')
            $(".required").after('<span style="color:red">*</span>');
    
            // Loop over them and prevent submission
            Array.prototype.filter.call(forms, function (form) {
                form.addEventListener('submit', function (event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                        form.classList.add('was-validated');
                        return;
                    }
        
                    var event = new Object();
                    event.username = $("#userName").val();
                    event.password = $("#password").val();
                    event.rePassword = $("#rePassword").val();
                    event.phoneNumber = $("#phoneNumber").val();
                    event.email = $("#email").val();
                    
                    window.location.href="index.html?username="+event.username+"&&password="+event.password+"&&phone="+event.phoneNumber+"&&email="+event.email;
                }, false)
            })

            var type = document.getElementById("type");
            var startTime = document.getElementById("startTime");
            type.addEventListener("change", function(event){
                if(type.value != '0'){
                    startTime.style.display="block";
                }
                else{
                    startTime.style.display="none";
                }
            })
        }, false)
    }())
    
    function back(){
        window.location.href="weekview.html";
    }