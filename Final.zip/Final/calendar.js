$(".schedule").find("td").click(function(){
    var date = $(this).find(".date").attr("value")
    var week = 1;
    if (date < 8) {
        week = 0;
    }
    else if (date > 14) {
        week = 2;
    }
    var url = window.location.href;
    var temp = url.split("?")[1]
    var temp2 = temp.split("&&weekNo=");
    if(temp2.length > 1){
        var temp3 = temp2[1].split("&&");
        if (temp3.length > 1){
            url = "weekView.html?" + temp2[0] + "&&weekNo=" + week;
            for(var i = 1; i < temp3.length; i++){
                url += "&&" + temp3[i];
            } 
        }
        else {
            url = "weekView.html?" + temp2[0] + "&&weekNo=" + week;
        }
    }
    else{
        url = "weekView.html?" + temp + "&&weekNo=" + week;
    }
    if (date < 22) {
        window.location.href = url;
    }
})

function profile() {
    var href = window.location.href.split("?");
    if (href.length == 2)
        window.location.href="profile.html"+"?"+href[1];
    else
        window.location.href="profile.html";
}